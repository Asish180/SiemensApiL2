﻿using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Linq;

namespace WebApplication1.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MoviesController : ControllerBase
    {
        public static IEnumerable<MovieEntity> Movies { get; set; }
        public MoviesController()
        {
            Movies = new List<MovieEntity>
            {
            new MovieEntity { Id = 1, Title = "Toy Story 1", Director = "John Lasseter" },
            new MovieEntity { Id = 2, Title = "Toy Story 4", Director = "Josh Cooley" },
            new MovieEntity { Id = 3, Title = "Arrival", Director = "Denis Villeneuve" },
            new MovieEntity { Id = 4, Title = "Interstellar", Director = "Christopher Nolan" },
            new MovieEntity { Id = 5, Title = "The Martian", Director = "Ridley Scott" },



             new MovieEntity { Id = 6, Title = "Avatar", Director = "James Cameron" },
            new MovieEntity { Id = 7, Title = "Prometheus", Director = "Ridley Scott" },
            new MovieEntity { Id = 8, Title = "Sunshine", Director = "Danny Boyle" },



             new MovieEntity { Id = 9, Title = "Serenity", Director = "Joss Whedon" },
            new MovieEntity { Id = 10, Title = "WALL-E", Director = "Andrew Stanton" },
            };
        }

        [HttpGet]
        public IActionResult Get()
        {
            return Ok(Movies);
        }

        [HttpGet("{id:int}")]
        public IActionResult GetMovies(int id)
        {
            var movie = Movies.Where(x=>x.Id==id);
            return Ok(movie);
        }

        [HttpGet]
        //TODO
        public IActionResult GetMoviesByFilter([FromQuery]string name,[FromQuery]int page=1)
        {
            if(page==0)
            {
                return BadRequest();
            }
            var recordsPerPage = 5;
            var recordSkip = recordsPerPage * (page - 1);
            var records = page * recordsPerPage;
            var movieList = Movies.Skip(recordSkip).Take(records);
            var movie = movieList.Where(x => x.Title.Contains(name));
            return Ok(movie);
        }


        [HttpPost]
        //TODO
        public IActionResult CreateMovies([FromBody]MovieEntity movie)
        {
            if(movie.Title.Length<5 || movie.Title.Length>15)
            {
                return BadRequest();
            }
            Movies.ToList().Add(movie);
            return Ok();
        }
    }



    public class MovieEntity
    {
        public int Id { get; set; }



        public string Title { get; set; }



        public string Director { get; set; }
    }
}


