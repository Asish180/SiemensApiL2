﻿using System;

namespace WebApplication1.Controllers
{
    internal class FromUriAttribute : Attribute
    {
    }
}